<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('dosen_mata_kuliah', function (Blueprint $table) {
            $table->engine = 'InnoDB';

            $table->string('kode_mk', 20);
            $table->string('nip', 20);
            $table->timestamps();

            // Composite Primary Key
            $table->primary(['kode_mk', 'nip']);

            // Foreign keys
            $table->foreign('kode_mk')
                ->references('kode_mk')
                ->on('mata_kuliahs')
                ->cascadeOnDelete();

            $table->foreign('nip')
                ->references('nip')
                ->on('dosens')
                ->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('dosen_mata_kuliah');
    }
};

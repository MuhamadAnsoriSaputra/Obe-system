<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('penilaians', function (Blueprint $table) {
            $table->id('id_nilai');
            $table->string('nim', 20);
            $table->string('kode_mk', 20);
            $table->string('id_teknik', 20);
            $table->decimal('nilai', 5, 2);
            $table->timestamps();

            $table->foreign('nim')->references('nim')->on('mahasiswas')->cascadeOnDelete();
            $table->foreign('kode_mk')->references('kode_mk')->on('mata_kuliahs')->cascadeOnDelete();
            $table->foreign('id_teknik')->references('id_teknik')->on('teknik_penilaians')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('penilaians');
    }
};

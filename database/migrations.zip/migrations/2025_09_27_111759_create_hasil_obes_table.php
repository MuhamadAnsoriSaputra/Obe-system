<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('hasil_obes', function (Blueprint $table) {
            $table->string('id_hasil', 20)->primary();
            $table->string('kode_cpl', 20);
            $table->string('capaian_persentase');
            $table->timestamps();

            $table->foreign('kode_cpl')->references('kode_cpl')->on('cpls')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('hasil_obes');
    }
};

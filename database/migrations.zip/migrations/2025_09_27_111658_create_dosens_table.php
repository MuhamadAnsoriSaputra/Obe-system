<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('dosens', function (Blueprint $table) {
            $table->string('nip', 20)->primary(); // ✅ pakai NIP konsisten
            $table->string('id_akun', 20);
            $table->string('nama');
            $table->string('gelar')->nullable();
            $table->string('jabatan')->nullable();
            $table->timestamps();

            $table->foreign('id_akun')
                ->references('id_akun')
                ->on('users')
                ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('dosens');
    }
};

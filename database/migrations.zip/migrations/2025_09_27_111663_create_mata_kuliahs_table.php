<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Tabel mata kuliah
        Schema::create('mata_kuliahs', function (Blueprint $table) {
            $table->string('kode_mk', 20)->primary();
            $table->string('nama_mk');
            $table->string('kode_angkatan', 20); // FK ke angkatan
            $table->timestamps();

            $table->foreign('kode_angkatan')
                ->references('kode_angkatan')
                ->on('angkatans')
                ->cascadeOnDelete();
        });

        // Pivot dosen - mata kuliah
        Schema::create('dosen_mata_kuliah', function (Blueprint $table) {
            $table->id();
            $table->string('kode_mk', 20);
            $table->string('nip', 20); // FK ke dosen
            $table->timestamps();

            $table->foreign('kode_mk')
                ->references('kode_mk')
                ->on('mata_kuliahs')
                ->cascadeOnDelete();

            $table->foreign('nip')
                ->references('nip')
                ->on('dosens')
                ->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('dosen_mata_kuliah');
        Schema::dropIfExists('mata_kuliahs');
    }
};
